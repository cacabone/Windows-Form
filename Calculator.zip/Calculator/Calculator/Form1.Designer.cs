﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnPlus = new Button();
            txtNumber1 = new TextBox();
            txtNumber2 = new TextBox();
            lbHistory = new ListBox();
            btnMinus = new Button();
            btnMultiply = new Button();
            btnDivide = new Button();
            btnClear = new Button();
            lblText1 = new Label();
            lblText = new Label();
            label1 = new Label();
            txtResult = new TextBox();
            SuspendLayout();
            // 
            // btnPlus
            // 
            btnPlus.Location = new Point(75, 200);
            btnPlus.Name = "btnPlus";
            btnPlus.Size = new Size(59, 35);
            btnPlus.TabIndex = 3;
            btnPlus.Text = "+";
            btnPlus.UseVisualStyleBackColor = true;
            btnPlus.Click += btnPlus_Click;
            // 
            // txtNumber1
            // 
            txtNumber1.Location = new Point(75, 65);
            txtNumber1.Name = "txtNumber1";
            txtNumber1.Size = new Size(116, 23);
            txtNumber1.TabIndex = 1;
            // 
            // txtNumber2
            // 
            txtNumber2.Location = new Point(75, 134);
            txtNumber2.Name = "txtNumber2";
            txtNumber2.Size = new Size(116, 23);
            txtNumber2.TabIndex = 2;
            // 
            // lbHistory
            // 
            lbHistory.FormattingEnabled = true;
            lbHistory.ItemHeight = 15;
            lbHistory.Location = new Point(388, 12);
            lbHistory.Name = "lbHistory";
            lbHistory.Size = new Size(207, 319);
            lbHistory.TabIndex = 8;
            lbHistory.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // btnMinus
            // 
            btnMinus.Location = new Point(200, 200);
            btnMinus.Name = "btnMinus";
            btnMinus.Size = new Size(59, 35);
            btnMinus.TabIndex = 4;
            btnMinus.Text = "-";
            btnMinus.UseVisualStyleBackColor = true;
            btnMinus.Click += btnMinus_Click;
            // 
            // btnMultiply
            // 
            btnMultiply.Location = new Point(75, 260);
            btnMultiply.Name = "btnMultiply";
            btnMultiply.Size = new Size(59, 35);
            btnMultiply.TabIndex = 5;
            btnMultiply.Text = "*";
            btnMultiply.UseVisualStyleBackColor = true;
            btnMultiply.Click += btnMultiply_Click;
            // 
            // btnDivide
            // 
            btnDivide.Location = new Point(200, 260);
            btnDivide.Name = "btnDivide";
            btnDivide.Size = new Size(59, 35);
            btnDivide.TabIndex = 6;
            btnDivide.Text = "/";
            btnDivide.UseVisualStyleBackColor = true;
            btnDivide.Click += btnDivide_Click;
            // 
            // btnClear
            // 
            btnClear.Location = new Point(300, 224);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(59, 35);
            btnClear.TabIndex = 7;
            btnClear.Text = "Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // lblText1
            // 
            lblText1.AutoSize = true;
            lblText1.Location = new Point(98, 47);
            lblText1.Name = "lblText1";
            lblText1.Size = new Size(76, 15);
            lblText1.TabIndex = 15;
            lblText1.Text = "Number One";
            // 
            // lblText
            // 
            lblText.AutoSize = true;
            lblText.Location = new Point(98, 116);
            lblText.Name = "lblText";
            lblText.Size = new Size(75, 15);
            lblText.TabIndex = 16;
            lblText.Text = "Number Two";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(273, 90);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 18;
            label1.Text = "Result";
            // 
            // txtResult
            // 
            txtResult.Location = new Point(233, 108);
            txtResult.Name = "txtResult";
            txtResult.Size = new Size(116, 23);
            txtResult.TabIndex = 17;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(620, 361);
            Controls.Add(label1);
            Controls.Add(txtResult);
            Controls.Add(lblText);
            Controls.Add(lblText1);
            Controls.Add(btnClear);
            Controls.Add(btnDivide);
            Controls.Add(btnMultiply);
            Controls.Add(btnMinus);
            Controls.Add(lbHistory);
            Controls.Add(txtNumber2);
            Controls.Add(txtNumber1);
            Controls.Add(btnPlus);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnPlus;
        private Button btnDivide;
        private Button btnClear;
        private TextBox txtNumber1;
        private TextBox txtNumber2;
        private ListBox lbHistory;
        private Button btnMinus;
        private Button btnMultiply;
        private Label lblText1;
        private Label lblText;
        private Label label1;
        private TextBox txtResult;
    }
}
