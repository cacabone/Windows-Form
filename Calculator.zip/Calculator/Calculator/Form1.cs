using Calculator.History;

namespace Calculator
{
    public partial class Form1 : Form
    {
        List<Historial> historial;
        decimal num1 = new decimal();
        decimal num2 = new decimal();
        decimal result = new decimal();
              
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            historial = new List<Historial> { };
        }

        private void btnClear_Click(object sender, EventArgs e)
        {       
            ClearAll();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
                

        }

        private void btnPlus_Click(object sender, EventArgs e)
        {
            num1 = System.Convert.ToDecimal(txtNumber1.Text);
            num2 = System.Convert.ToDecimal(txtNumber2.Text);
            result = num1 + num2;

            txtResult.Text = Convert.ToString(result);

            var Historia = new Historial();
            Historia.Number1 = Convert.ToString(num1);
            Historia.Number2 = Convert.ToString(num2);
            Historia.OperationSymbol = "+";
            Historia.Result = Convert.ToString(result);
            historial.Add(Historia);
            lbHistory.DataSource = null;
            lbHistory.DataSource = historial;

            ClearTxt();
        }

        
        private void btnMinus_Click(object sender, EventArgs e)
        {
            num1 = System.Convert.ToDecimal(txtNumber1.Text);
            num2 = System.Convert.ToDecimal(txtNumber2.Text);
            result = num1 - num2;

            txtResult.Text = Convert.ToString(result);

            var Historia = new Historial();
            Historia.Number1 = Convert.ToString(num1);
            Historia.Number2 = Convert.ToString(num2);
            Historia.OperationSymbol = "-";
            Historia.Result = Convert.ToString(result);
            historial.Add(Historia);
            lbHistory.DataSource = null;
            lbHistory.DataSource = historial;

            ClearTxt();
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            num1 = System.Convert.ToDecimal(txtNumber1.Text);
            num2 = System.Convert.ToDecimal(txtNumber2.Text);
            result = num1 * num2;

            txtResult.Text = Convert.ToString(result);

            var Historia = new Historial();
            Historia.Number1 = Convert.ToString(num1);
            Historia.Number2 = Convert.ToString(num2);
            Historia.OperationSymbol = "*";
            Historia.Result = Convert.ToString(result);
            historial.Add(Historia);
            lbHistory.DataSource = null;
            lbHistory.DataSource = historial;

            ClearTxt();
        }

        private void btnDivide_Click(object sender, EventArgs e)
        {
            num1 = System.Convert.ToDecimal(txtNumber1.Text);
            num2 = System.Convert.ToDecimal(txtNumber2.Text);
            result = num1 / num2;

            txtResult.Text = Convert.ToString(result);

            var Historia = new Historial();
            Historia.Number1 = Convert.ToString(num1);
            Historia.Number2 = Convert.ToString(num2);
            Historia.OperationSymbol = "/";
            Historia.Result = Convert.ToString(result);
            historial.Add(Historia);
            lbHistory.DataSource = null;
            lbHistory.DataSource = historial;

            ClearTxt();
        }

        private void ClearAll()
        {
            txtNumber1.Clear();
            txtNumber2.Clear();
            txtResult.Clear();
        }

        private void ClearTxt()
        {
           txtNumber1.Clear();
           txtNumber2.Clear();
        }
    }
}
