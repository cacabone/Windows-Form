﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calculator.History
{

    public class Historial
    {
        public string Number1 { get; set; }
        public string Number2 { get; set; }
        public string OperationSymbol { get; set; }
        public string Result { get; set; }

        public override string ToString()
        {
            return $"{Number1} {OperationSymbol} {Number2} = {Result}";     
        }
    }
}
